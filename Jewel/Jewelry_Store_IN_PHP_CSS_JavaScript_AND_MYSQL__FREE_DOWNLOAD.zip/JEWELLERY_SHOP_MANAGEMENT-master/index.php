<?php
header('location:index.html');
?>
